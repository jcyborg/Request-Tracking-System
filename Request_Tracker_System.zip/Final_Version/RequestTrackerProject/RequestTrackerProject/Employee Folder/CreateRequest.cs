﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using RequestTrackerProject.DataClassFolder;

namespace RequestTrackerProject
{
    public partial class CreateRequest : Form
    {
        /*
         Created by Jubril Bakare and Shikhar Sherchan
         ID 700673263
         */
        public CreateRequest()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close(); //exit form
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            //Quick validation :- //This part allows the app to ensure user enters all fields before execution
            string reqdesc = requestDescriptionTextBox.Text;
            string note = assignedTeamTextBox.Text;
            string creatorID = employeeIDTextBox.Text.ToString();
            string status = statusComboBox.Text.ToString();

            if (string.IsNullOrEmpty(reqdesc) || string.IsNullOrEmpty(note) || string.IsNullOrEmpty(creatorID.ToString()) || string.IsNullOrEmpty(status)) { errorProvider1.SetError(saveButton, "Please enter missing values"); }
            else
            {
                errorProvider1.Clear();

                try
                {

                    DataAccessObjects dao = new DataAccessObjects();
                    string sqlQuery = "insert into request (request_create_date, request_description, request_closing_note, request_creator_id, request_status) values (GETDATE(), @desc, @closingnote, @creatorID, @status)";

                    SqlCommand cmd = new SqlCommand(sqlQuery, dao.getConnection());
                    dao.openConnection();
                    cmd.Parameters.AddWithValue("@desc", requestDescriptionTextBox.Text);
                    cmd.Parameters.AddWithValue("@closingnote", assignedTeamTextBox.Text);
                    cmd.Parameters.AddWithValue("@creatorID", employeeIDTextBox.Text.ToString());
                    cmd.Parameters.AddWithValue("@status", statusComboBox.Text.ToString());
                    int i = cmd.ExecuteNonQuery();
                    if (i > 0)
                        
                    {
                        MessageBox.Show("Request created");
                    }


                    dao.closeConnection();

                    //This parts would clear the form after insert operation is completed
                    requestDescriptionTextBox.Text = String.Empty;
                    assignedTeamTextBox.Text = String.Empty;
                    employeeIDTextBox.Text = String.Empty;
                    statusComboBox.SelectedIndex = 0;
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }
        }

    }
}
