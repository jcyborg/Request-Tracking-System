﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RequestTrackerProject
{

    /*
     Created by Jubril Bakare
     ID 700673263
         */
    public partial class EmployeeOperation : Form
    {


        public EmployeeOperation()
        {
            InitializeComponent();
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void editMenu_Click(object sender, EventArgs e)
        {
            CreateRequest cr = new CreateRequest();
            cr.MdiParent = this;
            cr.Show();
        }

        private void viewMenu_Click(object sender, EventArgs e)
        {
            ViewRequest vr = new ViewRequest();
            vr.MdiParent = this;
            vr.Show();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox ab = new AboutBox();
            ab.MdiParent = this;
            ab.Show();
        }
    }
}
