﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace RequestTrackerProject
{
    /*Created by Jubril Bakare
     ID 700673263*/
    public partial class EmployeeLogin : Form
    {
        public EmployeeLogin()
        {
            InitializeComponent();
        }

        private void empExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }//exit

        private void empClearButton_Click(object sender, EventArgs e)
        {
            empUsernameTxtBox.Text = String.Empty;
            empPasswordTxtBox.Text = String.Empty;
        }

        private void empLoginButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Quick validation -: This part allows the app to ensure users enter a username and password
                string username = empUsernameTxtBox.Text;
                string password = empPasswordTxtBox.Text;

                if (string.IsNullOrEmpty(username)) { empErrorProvider.SetError(empUsernameTxtBox, "Please enter username"); }
                else if (string.IsNullOrEmpty(password)) { empErrorProvider.SetError(empPasswordTxtBox, "You need a password to proceed..."); }
                else
                {
                    empErrorProvider.Clear();
                    //This part communicates with the database to ensure the credentials entered are valid or not

                    string url = ConfigurationManager.ConnectionStrings["RequestTrackerProject.Properties.Settings.Setting"].ConnectionString;

                    string sqlquery = "select * from employees where Emp_User_Name=@Emp_User_Name and Emp_Password=@Emp_Password";

                    SqlConnection con = new SqlConnection(url);
                    SqlCommand cmd = new SqlCommand(sqlquery, con);
                    cmd.Parameters.AddWithValue("@Emp_User_Name", empUsernameTxtBox.Text);
                    cmd.Parameters.AddWithValue("@Emp_Password", empPasswordTxtBox.Text);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);

                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    con.Open();
                    int i = cmd.ExecuteNonQuery();
                    con.Close();

                    //this 'IF/Else' block would compare the users credentials to the database and proceed if it matches...
                    if (dt.Rows.Count > 0)
                    {

                        EmployeeOperation addForm = new EmployeeOperation();
                        RequestTracker rt = new RequestTracker();
                        rt.MdiParent = addForm.MdiParent;
                        addForm.Show();
                        this.Close();
                    }
                    else
                    {
                        empErrorProvider.SetError(empLoginButton, "Please enter Correct Username and Password");//error provider message
                    }//end of block that verifies credentials which communicates with database
                }//end of block that verifies user enters a username and password
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }//end of try catch
        }
    }
}
