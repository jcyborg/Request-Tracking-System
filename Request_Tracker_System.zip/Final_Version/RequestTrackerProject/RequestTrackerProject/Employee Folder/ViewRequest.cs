﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using RequestTrackerProject.DataClassFolder;

namespace RequestTrackerProject
{
    /*
     Created by Jubril Bakare
     ID 700673263
     */
    public partial class ViewRequest : Form
    {
        public ViewRequest()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        } //exit form

        private void ViewRequest_Load(object sender, EventArgs e)
        {

            try
            {
                string sqlQuery = "select * from request";

                DataAccessObjects dao = new DataAccessObjects();


                SqlDataAdapter adp = new SqlDataAdapter(sqlQuery, dao.getConnection());
                dao.openConnection();
                DataSet ds = new DataSet();
                adp.Fill(ds);
                resultDataGridView.DataSource = ds.Tables[0];

                DataTable dt = new DataTable();
                adp.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    itemsComboBox.Items.Add(dr["request_ID"].ToString());
                }


                dao.closeConnection();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        } // end ViewRequest_Load

        private void deleteButton_Click(object sender, EventArgs e)
        {
            DataAccessObjects dao = new DataAccessObjects();

            string query = "delete from request where request_ID = @reqID";
            dao.getConnection();
            dao.openConnection();
            SqlCommand cmd = new SqlCommand(query, dao.getConnection());
            cmd.Parameters.AddWithValue("@reqID", (itemsComboBox.SelectedItem).ToString());
            
            cmd.ExecuteNonQuery();
            
            MessageBox.Show("Request Deleted...Click View Request");
            
            dao.closeConnection();
            
        } // end deleteButton_Click

        private void updateButton_Click(object sender, EventArgs e)
        {
            CreateRequest cr = new CreateRequest();

            cr.Show();
        } // end updateButton_Click

        private void itemsComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    } // end class
} // end namespace
