﻿namespace RequestTrackerProject
{
    partial class AdminAddEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.addemplabel = new System.Windows.Forms.Label();
            this.fnlabel = new System.Windows.Forms.Label();
            this.lnlabel = new System.Windows.Forms.Label();
            this.teamnamelabel = new System.Windows.Forms.Label();
            this.unamelabel = new System.Windows.Forms.Label();
            this.pwlabel = new System.Windows.Forms.Label();
            this.firstNameTxtBox = new System.Windows.Forms.TextBox();
            this.lastNameTxtBox = new System.Windows.Forms.TextBox();
            this.adduNameTxtBox = new System.Windows.Forms.TextBox();
            this.addpWordTxtBox = new System.Windows.Forms.TextBox();
            this.addEmployeeBtn = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.teamIDcomboBox = new System.Windows.Forms.ComboBox();
            this.viewEmpBtn = new System.Windows.Forms.Button();
            this.addEmplerrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.prepBillionrb = new System.Windows.Forms.RadioButton();
            this.addEmpRadioButton = new System.Windows.Forms.RadioButton();
            this.prepbilllabel = new System.Windows.Forms.Label();
            this.reqTypecomboBox = new System.Windows.Forms.ComboBox();
            this.reqtyplabel = new System.Windows.Forms.Label();
            this.timeFrameLabel = new System.Windows.Forms.Label();
            this.timeFrameTextBox = new System.Windows.Forms.TextBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.servChargeLabel = new System.Windows.Forms.Label();
            this.resultLabel = new System.Windows.Forms.Label();
            this.adminAddEmployeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.addEmplerrorProvider)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adminAddEmployeeBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // addemplabel
            // 
            this.addemplabel.AutoSize = true;
            this.addemplabel.Font = new System.Drawing.Font("Lucida Bright", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addemplabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.addemplabel.Location = new System.Drawing.Point(217, 141);
            this.addemplabel.Name = "addemplabel";
            this.addemplabel.Size = new System.Drawing.Size(165, 18);
            this.addemplabel.TabIndex = 0;
            this.addemplabel.Text = "Add New Employee";
            // 
            // fnlabel
            // 
            this.fnlabel.AutoSize = true;
            this.fnlabel.Location = new System.Drawing.Point(217, 177);
            this.fnlabel.Name = "fnlabel";
            this.fnlabel.Size = new System.Drawing.Size(57, 13);
            this.fnlabel.TabIndex = 1;
            this.fnlabel.Text = "First Name";
            // 
            // lnlabel
            // 
            this.lnlabel.AutoSize = true;
            this.lnlabel.Location = new System.Drawing.Point(217, 227);
            this.lnlabel.Name = "lnlabel";
            this.lnlabel.Size = new System.Drawing.Size(58, 13);
            this.lnlabel.TabIndex = 2;
            this.lnlabel.Text = "Last Name";
            // 
            // teamnamelabel
            // 
            this.teamnamelabel.AutoSize = true;
            this.teamnamelabel.Location = new System.Drawing.Point(217, 269);
            this.teamnamelabel.Name = "teamnamelabel";
            this.teamnamelabel.Size = new System.Drawing.Size(65, 13);
            this.teamnamelabel.TabIndex = 3;
            this.teamnamelabel.Text = "Team Name";
            // 
            // unamelabel
            // 
            this.unamelabel.AutoSize = true;
            this.unamelabel.Location = new System.Drawing.Point(217, 328);
            this.unamelabel.Name = "unamelabel";
            this.unamelabel.Size = new System.Drawing.Size(60, 13);
            this.unamelabel.TabIndex = 4;
            this.unamelabel.Text = "User Name";
            // 
            // pwlabel
            // 
            this.pwlabel.AutoSize = true;
            this.pwlabel.Location = new System.Drawing.Point(224, 377);
            this.pwlabel.Name = "pwlabel";
            this.pwlabel.Size = new System.Drawing.Size(53, 13);
            this.pwlabel.TabIndex = 5;
            this.pwlabel.Text = "Password";
            // 
            // firstNameTxtBox
            // 
            this.firstNameTxtBox.Location = new System.Drawing.Point(318, 169);
            this.firstNameTxtBox.Name = "firstNameTxtBox";
            this.firstNameTxtBox.Size = new System.Drawing.Size(121, 20);
            this.firstNameTxtBox.TabIndex = 6;
            // 
            // lastNameTxtBox
            // 
            this.lastNameTxtBox.Location = new System.Drawing.Point(318, 220);
            this.lastNameTxtBox.Name = "lastNameTxtBox";
            this.lastNameTxtBox.Size = new System.Drawing.Size(121, 20);
            this.lastNameTxtBox.TabIndex = 7;
            // 
            // adduNameTxtBox
            // 
            this.adduNameTxtBox.Location = new System.Drawing.Point(318, 321);
            this.adduNameTxtBox.Name = "adduNameTxtBox";
            this.adduNameTxtBox.Size = new System.Drawing.Size(121, 20);
            this.adduNameTxtBox.TabIndex = 9;
            this.adduNameTxtBox.TextChanged += new System.EventHandler(this.adduNameTxtBox_TextChanged);
            // 
            // addpWordTxtBox
            // 
            this.addpWordTxtBox.Location = new System.Drawing.Point(318, 377);
            this.addpWordTxtBox.Name = "addpWordTxtBox";
            this.addpWordTxtBox.PasswordChar = '*';
            this.addpWordTxtBox.Size = new System.Drawing.Size(121, 20);
            this.addpWordTxtBox.TabIndex = 10;
            // 
            // addEmployeeBtn
            // 
            this.addEmployeeBtn.Location = new System.Drawing.Point(512, 197);
            this.addEmployeeBtn.Name = "addEmployeeBtn";
            this.addEmployeeBtn.Size = new System.Drawing.Size(109, 23);
            this.addEmployeeBtn.TabIndex = 11;
            this.addEmployeeBtn.Text = "Add &Employee";
            this.addEmployeeBtn.UseVisualStyleBackColor = true;
            this.addEmployeeBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(512, 336);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 23);
            this.button2.TabIndex = 12;
            this.button2.Text = "&Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // teamIDcomboBox
            // 
            this.teamIDcomboBox.FormattingEnabled = true;
            this.teamIDcomboBox.Location = new System.Drawing.Point(318, 269);
            this.teamIDcomboBox.Name = "teamIDcomboBox";
            this.teamIDcomboBox.Size = new System.Drawing.Size(121, 21);
            this.teamIDcomboBox.TabIndex = 13;
            this.teamIDcomboBox.SelectedIndexChanged += new System.EventHandler(this.teamIDcomboBox_SelectedIndexChanged);
            // 
            // viewEmpBtn
            // 
            this.viewEmpBtn.Location = new System.Drawing.Point(512, 265);
            this.viewEmpBtn.Name = "viewEmpBtn";
            this.viewEmpBtn.Size = new System.Drawing.Size(109, 23);
            this.viewEmpBtn.TabIndex = 14;
            this.viewEmpBtn.Text = "Manage &Employees";
            this.viewEmpBtn.UseVisualStyleBackColor = true;
            this.viewEmpBtn.Click += new System.EventHandler(this.viewEmpBtn_Click);
            // 
            // addEmplerrorProvider
            // 
            this.addEmplerrorProvider.ContainerControl = this;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.prepBillionrb);
            this.groupBox1.Controls.Add(this.addEmpRadioButton);
            this.groupBox1.Location = new System.Drawing.Point(24, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(149, 154);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select Option";
            // 
            // prepBillionrb
            // 
            this.prepBillionrb.AutoSize = true;
            this.prepBillionrb.Location = new System.Drawing.Point(6, 92);
            this.prepBillionrb.Name = "prepBillionrb";
            this.prepBillionrb.Size = new System.Drawing.Size(92, 17);
            this.prepBillionrb.TabIndex = 1;
            this.prepBillionrb.TabStop = true;
            this.prepBillionrb.Text = "Prepare Billing";
            this.prepBillionrb.UseVisualStyleBackColor = true;
            this.prepBillionrb.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // addEmpRadioButton
            // 
            this.addEmpRadioButton.AutoSize = true;
            this.addEmpRadioButton.Location = new System.Drawing.Point(6, 41);
            this.addEmpRadioButton.Name = "addEmpRadioButton";
            this.addEmpRadioButton.Size = new System.Drawing.Size(118, 17);
            this.addEmpRadioButton.TabIndex = 0;
            this.addEmpRadioButton.TabStop = true;
            this.addEmpRadioButton.Text = "Add New Employee";
            this.addEmpRadioButton.UseVisualStyleBackColor = true;
            this.addEmpRadioButton.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // prepbilllabel
            // 
            this.prepbilllabel.AutoSize = true;
            this.prepbilllabel.Font = new System.Drawing.Font("Lucida Fax", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prepbilllabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.prepbilllabel.Location = new System.Drawing.Point(208, 32);
            this.prepbilllabel.Name = "prepbilllabel";
            this.prepbilllabel.Size = new System.Drawing.Size(137, 18);
            this.prepbilllabel.TabIndex = 16;
            this.prepbilllabel.Text = "Request Billing";
            // 
            // reqTypecomboBox
            // 
            this.reqTypecomboBox.FormattingEnabled = true;
            this.reqTypecomboBox.Items.AddRange(new object[] {
            "BackEnd Engineering",
            "FrontEnd Works",
            "Design Analysis",
            "Database Issue"});
            this.reqTypecomboBox.Location = new System.Drawing.Point(308, 60);
            this.reqTypecomboBox.Name = "reqTypecomboBox";
            this.reqTypecomboBox.Size = new System.Drawing.Size(121, 21);
            this.reqTypecomboBox.TabIndex = 17;
            // 
            // reqtyplabel
            // 
            this.reqtyplabel.AutoSize = true;
            this.reqtyplabel.Location = new System.Drawing.Point(211, 67);
            this.reqtyplabel.Name = "reqtyplabel";
            this.reqtyplabel.Size = new System.Drawing.Size(74, 13);
            this.reqtyplabel.TabIndex = 18;
            this.reqtyplabel.Text = "Request Type";
            // 
            // timeFrameLabel
            // 
            this.timeFrameLabel.AutoSize = true;
            this.timeFrameLabel.Location = new System.Drawing.Point(211, 101);
            this.timeFrameLabel.Name = "timeFrameLabel";
            this.timeFrameLabel.Size = new System.Drawing.Size(107, 13);
            this.timeFrameLabel.TabIndex = 19;
            this.timeFrameLabel.Text = "Time Frame (in days):";
            // 
            // timeFrameTextBox
            // 
            this.timeFrameTextBox.Location = new System.Drawing.Point(324, 101);
            this.timeFrameTextBox.Name = "timeFrameTextBox";
            this.timeFrameTextBox.Size = new System.Drawing.Size(105, 20);
            this.timeFrameTextBox.TabIndex = 20;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(524, 135);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(75, 23);
            this.calcButton.TabIndex = 21;
            this.calcButton.Text = "&Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // servChargeLabel
            // 
            this.servChargeLabel.AutoSize = true;
            this.servChargeLabel.Location = new System.Drawing.Point(458, 49);
            this.servChargeLabel.Name = "servChargeLabel";
            this.servChargeLabel.Size = new System.Drawing.Size(86, 13);
            this.servChargeLabel.TabIndex = 22;
            this.servChargeLabel.Text = "Service Charge: ";
            // 
            // resultLabel
            // 
            this.resultLabel.AutoSize = true;
            this.resultLabel.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.resultLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.resultLabel.Location = new System.Drawing.Point(461, 67);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Padding = new System.Windows.Forms.Padding(120, 25, 120, 25);
            this.resultLabel.Size = new System.Drawing.Size(242, 65);
            this.resultLabel.TabIndex = 23;
            // 
            // adminAddEmployeeBindingSource
            // 
            this.adminAddEmployeeBindingSource.DataSource = typeof(RequestTrackerProject.AdminAddEmployee);
            // 
            // AdminAddEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1157, 544);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.servChargeLabel);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.timeFrameTextBox);
            this.Controls.Add(this.timeFrameLabel);
            this.Controls.Add(this.reqtyplabel);
            this.Controls.Add(this.reqTypecomboBox);
            this.Controls.Add(this.prepbilllabel);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.viewEmpBtn);
            this.Controls.Add(this.teamIDcomboBox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.addEmployeeBtn);
            this.Controls.Add(this.addpWordTxtBox);
            this.Controls.Add(this.adduNameTxtBox);
            this.Controls.Add(this.lastNameTxtBox);
            this.Controls.Add(this.firstNameTxtBox);
            this.Controls.Add(this.pwlabel);
            this.Controls.Add(this.unamelabel);
            this.Controls.Add(this.teamnamelabel);
            this.Controls.Add(this.lnlabel);
            this.Controls.Add(this.fnlabel);
            this.Controls.Add(this.addemplabel);
            this.Name = "AdminAddEmployee";
            this.Text = "AdminOperations";
            this.Load += new System.EventHandler(this.AdminAddEmployee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.addEmplerrorProvider)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adminAddEmployeeBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label addemplabel;
        private System.Windows.Forms.Label fnlabel;
        private System.Windows.Forms.Label lnlabel;
        private System.Windows.Forms.Label teamnamelabel;
        private System.Windows.Forms.Label unamelabel;
        private System.Windows.Forms.Label pwlabel;
        private System.Windows.Forms.TextBox firstNameTxtBox;
        private System.Windows.Forms.TextBox lastNameTxtBox;
        private System.Windows.Forms.TextBox adduNameTxtBox;
        private System.Windows.Forms.TextBox addpWordTxtBox;
        private System.Windows.Forms.Button addEmployeeBtn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox teamIDcomboBox;
        private System.Windows.Forms.Button viewEmpBtn;
        private System.Windows.Forms.ErrorProvider addEmplerrorProvider;
        private System.Windows.Forms.BindingSource adminAddEmployeeBindingSource;
        private System.Windows.Forms.Label prepbilllabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton prepBillionrb;
        private System.Windows.Forms.RadioButton addEmpRadioButton;
        private System.Windows.Forms.Label reqtyplabel;
        private System.Windows.Forms.ComboBox reqTypecomboBox;
        private System.Windows.Forms.Label resultLabel;
        private System.Windows.Forms.Label servChargeLabel;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.TextBox timeFrameTextBox;
        private System.Windows.Forms.Label timeFrameLabel;
    }
}