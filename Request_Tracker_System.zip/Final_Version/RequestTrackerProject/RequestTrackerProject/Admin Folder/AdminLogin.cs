﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


using System.Configuration;
using RequestTrackerProject.DataClassFolder;

namespace RequestTrackerProject
{
    /*
     Created by Jubril Bakare
     ID 700673263*/
    public partial class AdminLogin : Form
    {
        public AdminLogin()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void exitTextBox_Click(object sender, EventArgs e)
        {
            this.Close();
        }//exit

        private void clearTextBox_Click(object sender, EventArgs e)
        {
            adminUserTxtBox.Text = String.Empty;
            adminPasswordTxtBox.Text = String.Empty;
        }//end of clear button

        private void loginTextBox_Click(object sender, EventArgs e)
        {
            try
            {
                // Quick validation -: This part allows the app to ensure users enter a username and password
                string username = adminUserTxtBox.Text;
                string password = adminPasswordTxtBox.Text;
                
                if (string.IsNullOrEmpty(username)) { adminerrorProvider.SetError(adminUserTxtBox, "Please enter username");}
                else if (string.IsNullOrEmpty(password)) { adminerrorProvider.SetError(adminPasswordTxtBox, "You need a password to proceed..."); }
                else
                {
                    adminerrorProvider.Clear();

                    //This part communicates with the database to ensure the credentials entered are valid or not
                    string sqlquery = "select * from admin where admin_user_name=@usr and admin_password=@pwd";

                    //instantiating the DataAccessClass
                    DataAccessObjects dao = new DataAccessObjects();
                    
                    SqlCommand cmd = new SqlCommand(sqlquery, dao.getConnection());
                    dao.openConnection();
                    cmd.Parameters.AddWithValue("@usr", adminUserTxtBox.Text);
                    cmd.Parameters.AddWithValue("@pwd", adminPasswordTxtBox.Text);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);

                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                   
                    //this 'IF/Else' block would compare the users credentials to the database and proceed if it matches...
                    if (dt.Rows.Count > 0)
                    {

                        AdminAddEmployee addForm = new AdminAddEmployee();
                        RequestTracker rt = new RequestTracker();
                        addForm.MdiParent = rt.MdiParent;
                        addForm.Show();
                        this.Close();
                    }
                    else
                    {
                        adminerrorProvider.SetError(adminLoginButton, "Please enter Correct Username and Password");//error provider message
                    }//end IF/else

                    dao.closeConnection();
                }//end of block that verifies user enters a username and password
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }//end of try catch
        }//end of login method

        private void AdminLogin_Load(object sender, EventArgs e)
        {

        }
    }//end class
}//end namespace
