﻿namespace RequestTrackerProject
{
    partial class AdminLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.adminLoginButton = new System.Windows.Forms.Button();
            this.clearTextBox = new System.Windows.Forms.Button();
            this.exitTextBox = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.adminUserTxtBox = new System.Windows.Forms.TextBox();
            this.adminPasswordTxtBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.adminerrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.adminerrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // adminLoginButton
            // 
            this.adminLoginButton.Location = new System.Drawing.Point(113, 252);
            this.adminLoginButton.Name = "adminLoginButton";
            this.adminLoginButton.Size = new System.Drawing.Size(75, 23);
            this.adminLoginButton.TabIndex = 0;
            this.adminLoginButton.Text = "&Login";
            this.adminLoginButton.UseVisualStyleBackColor = true;
            this.adminLoginButton.Click += new System.EventHandler(this.loginTextBox_Click);
            // 
            // clearTextBox
            // 
            this.clearTextBox.Location = new System.Drawing.Point(241, 252);
            this.clearTextBox.Name = "clearTextBox";
            this.clearTextBox.Size = new System.Drawing.Size(75, 23);
            this.clearTextBox.TabIndex = 1;
            this.clearTextBox.Text = "&Clear";
            this.clearTextBox.UseVisualStyleBackColor = true;
            this.clearTextBox.Click += new System.EventHandler(this.clearTextBox_Click);
            // 
            // exitTextBox
            // 
            this.exitTextBox.Location = new System.Drawing.Point(373, 252);
            this.exitTextBox.Name = "exitTextBox";
            this.exitTextBox.Size = new System.Drawing.Size(75, 23);
            this.exitTextBox.TabIndex = 2;
            this.exitTextBox.Text = "E&xit";
            this.exitTextBox.UseVisualStyleBackColor = true;
            this.exitTextBox.Click += new System.EventHandler(this.exitTextBox_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(164, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "User Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(164, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Password";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // adminUserTxtBox
            // 
            this.adminUserTxtBox.Location = new System.Drawing.Point(241, 94);
            this.adminUserTxtBox.Name = "adminUserTxtBox";
            this.adminUserTxtBox.Size = new System.Drawing.Size(150, 20);
            this.adminUserTxtBox.TabIndex = 5;
            // 
            // adminPasswordTxtBox
            // 
            this.adminPasswordTxtBox.Location = new System.Drawing.Point(241, 147);
            this.adminPasswordTxtBox.Name = "adminPasswordTxtBox";
            this.adminPasswordTxtBox.PasswordChar = '*';
            this.adminPasswordTxtBox.Size = new System.Drawing.Size(150, 20);
            this.adminPasswordTxtBox.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(251, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Admin Login";
            // 
            // adminerrorProvider
            // 
            this.adminerrorProvider.ContainerControl = this;
            // 
            // AdminLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 385);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.adminPasswordTxtBox);
            this.Controls.Add(this.adminUserTxtBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.exitTextBox);
            this.Controls.Add(this.clearTextBox);
            this.Controls.Add(this.adminLoginButton);
            this.Name = "AdminLogin";
            this.Text = "AdminLogin";
            this.Load += new System.EventHandler(this.AdminLogin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.adminerrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button adminLoginButton;
        private System.Windows.Forms.Button clearTextBox;
        private System.Windows.Forms.Button exitTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox adminUserTxtBox;
        private System.Windows.Forms.TextBox adminPasswordTxtBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ErrorProvider adminerrorProvider;
    }
}