﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace RequestTrackerProject
{
    /*Created by Jubril Bakare
     ID 700673263*/
    public partial class EmployeesDataGrid : Form
    {
        public EmployeesDataGrid()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            try
            {

            string connUrl = ConfigurationManager.ConnectionStrings["RequestTrackerProject.Properties.Settings.Setting"].ConnectionString;
            SqlConnection konekt = new SqlConnection(connUrl);
            string qry = "delete from employees where last_name =@emp";
            SqlCommand cmd = new SqlCommand(qry, konekt);
            cmd.Parameters.AddWithValue("@emp", empIDcomboBox.SelectedItem);
            konekt.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dr.Read();
            MessageBox.Show("Employee deleted");
                dataGridView1.Update();
            konekt.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void EmployeesDataGrid_Load(object sender, EventArgs e)
        {
            string connUrl = ConfigurationManager.ConnectionStrings["RequestTrackerProject.Properties.Settings.Setting"].ConnectionString;
            SqlConnection konekt = new SqlConnection(connUrl);
            string qry = "select * from employees";
            
           
            SqlDataAdapter adp = new SqlDataAdapter(qry, konekt);
            konekt.Open();
            DataSet ds = new DataSet();
            adp.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

            DataTable dt = new DataTable();
            adp.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                empIDcomboBox.Items.Add(dr["last_name"].ToString());
            }

            konekt.Close();
        }

        private void analysisButton_Click(object sender, EventArgs e)
        {
            string connUrl = ConfigurationManager.ConnectionStrings["RequestTrackerProject.Properties.Settings.Setting"].ConnectionString;
            SqlConnection konekt = new SqlConnection(connUrl);
            string qry = "SELECT first_name, last_name, team_name, emp_user_name FROM employees e JOIN team t ON e.team_ID = t.team_ID; ";

            //konekt.GenericSelectQuery(qry);
            SqlDataAdapter adp = new SqlDataAdapter(qry, konekt);
            konekt.Open();
            DataSet ds = new DataSet();
            adp.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            konekt.Close();
        }

        private void empIDcomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*string connstring = ConfigurationManager.ConnectionStrings["RequestTrackerProject.Properties.Settings.Setting"].ConnectionString;
            SqlConnection conn = new SqlConnection(connstring);


            try
            {
                string query = "select employee_id, first_name from employees";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                conn.Open();
                DataSet ds = new DataSet();
                da.Fill(ds, "employees");

                empIDcomboBox.DisplayMember = "employee_id";
                empIDcomboBox.ValueMember = "first_name";
                empIDcomboBox.DataSource = ds.Tables[0];


            }
            catch (Exception ex)
            {

                MessageBox.Show("Error occured loading employee table!", ex.Message);
            }*/
            
        }
    }
    
}
