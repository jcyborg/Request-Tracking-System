﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RequestTrackerProject.SomeInheritancePoly
{
    class FrontEndBilling : BackEndBilling
    {
        private const decimal amount = 2200m;
        
        public FrontEndBilling(int _NumberOfDays): base(_NumberOfDays)
        {

        }
        
        public override decimal BillingPrice()
        {

            return WorkingDays * amount;
        }

        public override string ToString()
        {
            return $"Type of Service: {GetType().Name}; Bill per day: {amount}; Total bill for this service: ";
            //the toString method is overridden to just display the name of the class and the properties.
        }//end toString()
    }
}
