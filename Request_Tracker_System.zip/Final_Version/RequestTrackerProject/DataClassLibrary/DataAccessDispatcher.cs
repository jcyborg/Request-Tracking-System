﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

using System.Data;

namespace DataClassLibrary
{
    /*
     Created by Jubril Bakare
     ID 700673263*/
    public class DataAccessDispatcher
    {

        public DataSet SelectQuery(string sqlString)
        {
            RawDataAccess rw = new RawDataAccess();

            DataSet nwDataSet = new DataSet();
            try
            {
                SqlDataAdapter nwDataAdapter = new SqlDataAdapter(sqlString, rw.GetConnection());
                //open connection
                rw.openConnection();

                //fill the data:
                nwDataAdapter.Fill(nwDataSet);

                //return the data set
                return nwDataSet;

              
            }
            finally
            {
                rw.closeConnection();
            }
        }

        public void addNewEmployee(string insertquery, int result, string firstName, string lastName, int teamID, string uName, string password)
        {
            try
            {
                
                RawDataAccess konekt = new RawDataAccess();

                SqlCommand cmd = new SqlCommand(insertquery, konekt.GetConnection());
                konekt.openConnection();
                cmd.Parameters.AddWithValue("@First_Name", firstName);
                cmd.Parameters.AddWithValue("@Last_Name", lastName);
                cmd.Parameters.AddWithValue("@Team_ID", teamID);
                cmd.Parameters.AddWithValue("@Emp_User_Name", uName);
                cmd.Parameters.AddWithValue("@Emp_Password", password);

                result = cmd.ExecuteNonQuery();
                konekt.closeConnection();
                
            }
            catch (Exception)
            {
                
            }
        }

        public void adminLogin(string selectquery, string username, string password)
        {
            RawDataAccess conn = new RawDataAccess();
            SqlCommand cmd = new SqlCommand(selectquery, conn.GetConnection());
            conn.openConnection();
            cmd.Parameters.AddWithValue("@admin_user_name", username);
            cmd.Parameters.AddWithValue("@admin_password", password);

            cmd.ExecuteNonQuery();
            conn.closeConnection();
        }


    }
}
