﻿namespace RequestTrackerProject
{
    partial class EmployeeLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.empLoginButton = new System.Windows.Forms.Button();
            this.empClearButton = new System.Windows.Forms.Button();
            this.empExitButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.empUsernameTxtBox = new System.Windows.Forms.TextBox();
            this.empPasswordTxtBox = new System.Windows.Forms.TextBox();
            this.empErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.empErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // empLoginButton
            // 
            this.empLoginButton.Location = new System.Drawing.Point(112, 249);
            this.empLoginButton.Name = "empLoginButton";
            this.empLoginButton.Size = new System.Drawing.Size(75, 23);
            this.empLoginButton.TabIndex = 0;
            this.empLoginButton.Text = "&Login";
            this.empLoginButton.UseVisualStyleBackColor = true;
            this.empLoginButton.Click += new System.EventHandler(this.empLoginButton_Click);
            // 
            // empClearButton
            // 
            this.empClearButton.Location = new System.Drawing.Point(236, 249);
            this.empClearButton.Name = "empClearButton";
            this.empClearButton.Size = new System.Drawing.Size(75, 23);
            this.empClearButton.TabIndex = 1;
            this.empClearButton.Text = "&Clear";
            this.empClearButton.UseVisualStyleBackColor = true;
            this.empClearButton.Click += new System.EventHandler(this.empClearButton_Click);
            // 
            // empExitButton
            // 
            this.empExitButton.Location = new System.Drawing.Point(367, 249);
            this.empExitButton.Name = "empExitButton";
            this.empExitButton.Size = new System.Drawing.Size(75, 23);
            this.empExitButton.TabIndex = 2;
            this.empExitButton.Text = "E&xit";
            this.empExitButton.UseVisualStyleBackColor = true;
            this.empExitButton.Click += new System.EventHandler(this.empExitButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(140, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "User Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(140, 142);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(242, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Employee Login";
            // 
            // empUsernameTxtBox
            // 
            this.empUsernameTxtBox.Location = new System.Drawing.Point(236, 106);
            this.empUsernameTxtBox.Name = "empUsernameTxtBox";
            this.empUsernameTxtBox.Size = new System.Drawing.Size(141, 20);
            this.empUsernameTxtBox.TabIndex = 6;
            // 
            // empPasswordTxtBox
            // 
            this.empPasswordTxtBox.Location = new System.Drawing.Point(236, 142);
            this.empPasswordTxtBox.Name = "empPasswordTxtBox";
            this.empPasswordTxtBox.PasswordChar = '*';
            this.empPasswordTxtBox.Size = new System.Drawing.Size(141, 20);
            this.empPasswordTxtBox.TabIndex = 7;
            // 
            // empErrorProvider
            // 
            this.empErrorProvider.ContainerControl = this;
            // 
            // EmployeeLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 335);
            this.Controls.Add(this.empPasswordTxtBox);
            this.Controls.Add(this.empUsernameTxtBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.empExitButton);
            this.Controls.Add(this.empClearButton);
            this.Controls.Add(this.empLoginButton);
            this.Name = "EmployeeLogin";
            this.Text = "EmployeeLogin";
            ((System.ComponentModel.ISupportInitialize)(this.empErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button empLoginButton;
        private System.Windows.Forms.Button empClearButton;
        private System.Windows.Forms.Button empExitButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox empUsernameTxtBox;
        private System.Windows.Forms.TextBox empPasswordTxtBox;
        private System.Windows.Forms.ErrorProvider empErrorProvider;
    }
}