﻿using System.Configuration;
using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RequestTrackerProject.SomeInheritancePoly;

namespace RequestTrackerProject
{
    public partial class AdminAddEmployee : Form
    {
        /*
         * Created by Jubril Bakare
         * 700673263
         */
        private int daysOfWork;
        private decimal totalDue;
        public AdminAddEmployee()
        {
            InitializeComponent();
        }

        /*
         * declare connection string
         * declare query
         * create connection object and insert connection string as arguement
         * create command object and insert query and connection object as arguements
         * open connection
         * execute query
         * close connection
         */
        private void button1_Click(object sender, EventArgs e)
        {
            //Quick validation :- //This part allows the app to ensure user enters all fields before execution
            string firstName = firstNameTxtBox.Text;
            string lastName = lastNameTxtBox.Text;
            int teamID = int.Parse(teamIDcomboBox.SelectedIndex.ToString());
            string userName = adduNameTxtBox.Text;
            string password = addpWordTxtBox.Text;

            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(teamID.ToString()) || string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(password)) { addEmplerrorProvider.SetError(addEmployeeBtn, "Please enter missing values"); }
            else
            {
                addEmplerrorProvider.Clear();

                try
                {
                    string url = ConfigurationManager.ConnectionStrings["RequestTrackerProject.Properties.Settings.Setting"].ConnectionString;
                    string sql = "insert into employees (first_name, last_name, team_ID, Emp_User_name, Emp_Password) values (@first_name, @last_name, @team_ID, @Emp_User_name, @Emp_Password)";
                   
                    SqlConnection sc = new SqlConnection(url);
                    SqlCommand cmd = new SqlCommand(sql, sc);
                    sc.Open();
                    cmd.Parameters.AddWithValue("@first_name", firstNameTxtBox.Text);
                    cmd.Parameters.AddWithValue("@last_name", lastNameTxtBox.Text);
                    cmd.Parameters.AddWithValue("@team_ID", teamIDcomboBox.SelectedIndex);
                    cmd.Parameters.AddWithValue("@Emp_User_name", adduNameTxtBox.Text);
                    cmd.Parameters.AddWithValue("@Emp_Password", addpWordTxtBox.Text);
                   // cmd.CommandType = CommandType.Text;
                    
                    cmd.ExecuteNonQuery();
                    
                   MessageBox.Show("New Employee Added Successfully");
                   
                   
                    sc.Close();
                    cmd.Dispose();

                    //This parts would clear the textbox after insert operation is completed
                    firstNameTxtBox.Text = String.Empty;
                    lastNameTxtBox.Text = String.Empty;
                    teamIDcomboBox.Text = String.Empty;
                    adduNameTxtBox.Text = String.Empty;
                    addpWordTxtBox.Text = String.Empty;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }      

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }// exit

        private void adduNameTxtBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void teamIDcomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void viewEmpBtn_Click(object sender, EventArgs e)
        {
            EmployeesDataGrid emp = new EmployeesDataGrid();
            RequestTracker rqs = new RequestTracker();
            emp.MdiParent = rqs.MdiParent;
            emp.Show();
        }

        private void AdminAddEmployee_Load(object sender, EventArgs e)
        {
            addEmpRadioButton.Checked = true;

            string url = ConfigurationManager.ConnectionStrings["RequestTrackerProject.Properties.Settings.Setting"].ConnectionString;
            SqlConnection conn = new SqlConnection(url);
            SqlCommand cmd = new SqlCommand(url, conn);
            teamIDcomboBox.Items.Clear();
            cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select team_id, team_name from team";
            conn.Open();
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                teamIDcomboBox.Items.Add(dr["team_name"].ToString());
            }
            conn.Close();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            prepbilllabel.Visible = true;
            reqtyplabel.Visible = true;
            reqTypecomboBox.Visible = true;
            timeFrameLabel.Visible = true;
            timeFrameTextBox.Visible = true;
            servChargeLabel.Visible = true;
            resultLabel.Visible = true;
            calcButton.Visible = true;
            addemplabel.Visible = false;
            fnlabel.Visible = false;
            lnlabel.Visible = false;
            teamnamelabel.Visible = false;
            unamelabel.Visible = false;
            pwlabel.Visible = false;
            addEmployeeBtn.Visible = false;
            firstNameTxtBox.Visible = false;
            lastNameTxtBox.Visible = false;
            teamIDcomboBox.Visible = false;
            adduNameTxtBox.Visible = false;
            addpWordTxtBox.Visible = false;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            prepbilllabel.Visible = false;
            reqtyplabel.Visible = false;
            reqTypecomboBox.Visible = false;
            timeFrameLabel.Visible = false;
            timeFrameTextBox.Visible = false;
            servChargeLabel.Visible = false;
            resultLabel.Visible = false;
            calcButton.Visible = false;
            addemplabel.Visible = true;
            fnlabel.Visible = true;
            lnlabel.Visible = true;
            teamnamelabel.Visible = true;
            unamelabel.Visible = true;
            pwlabel.Visible = true;
            addEmployeeBtn.Visible = true;
            firstNameTxtBox.Visible = true;
            lastNameTxtBox.Visible = true;
            teamIDcomboBox.Visible = true;
            adduNameTxtBox.Visible = true;
            addpWordTxtBox.Visible = true;

        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            addEmplerrorProvider.Clear(); //clears error provider

            if (reqTypecomboBox.SelectedIndex != -1)
            {

                if (reqTypecomboBox.SelectedIndex == 0 || reqTypecomboBox.SelectedIndex == 1 || reqTypecomboBox.SelectedIndex == 2 || reqTypecomboBox.SelectedIndex == 3)
                {
                    try
                    {
                        if (reqTypecomboBox.SelectedIndex == 0)
                        {
                            daysOfWork = int.Parse(timeFrameTextBox.Text);
                            BackEndBilling beb = new BackEndBilling(daysOfWork);
                            totalDue = beb.BillingPrice();
                            resultLabel.Text = beb.ToString() + totalDue.ToString("C");
                        }
                        else if (reqTypecomboBox.SelectedIndex == 1)
                        {
                            daysOfWork = int.Parse(timeFrameTextBox.Text);
                            FrontEndBilling feb = new FrontEndBilling(daysOfWork);
                            totalDue = feb.BillingPrice();
                            resultLabel.Text = totalDue.ToString("C");
                        }
                        else if (reqTypecomboBox.SelectedIndex == 2)
                        {
                            daysOfWork = int.Parse(timeFrameTextBox.Text);
                            DesignAnalysisBilling dab = new DesignAnalysisBilling(daysOfWork);
                            totalDue = dab.BillingPrice();
                            resultLabel.Text = totalDue.ToString("C");
                        }
                        else if (reqTypecomboBox.SelectedIndex == 3)
                        {
                            daysOfWork = int.Parse(timeFrameTextBox.Text);
                            DataBaseBilling dbb = new DataBaseBilling(daysOfWork);
                            totalDue = dbb.BillingPrice();
                            resultLabel.Text = totalDue.ToString("C");
                        }
                        
                    }
                    catch (Exception ex)
                    {
                        addEmplerrorProvider.SetError(resultLabel, "Enter a valid Input..." + ex.Message);
                    }
                }
            }
            else
            {
                resultLabel.Text = "Select a Billing Type";
            }
        }
    }
}

