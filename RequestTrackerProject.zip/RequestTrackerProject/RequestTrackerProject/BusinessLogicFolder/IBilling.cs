﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RequestTrackerProject.SomeInheritancePoly
{
    /* Created by Jubril Bakare
     ID 700673263*/
    interface IBilling
    {
        decimal BillingPrice();

        int WorkingDays { get; set; }
    }
}
