﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RequestTrackerProject.SomeInheritancePoly
{
    /*Created by Jubril Bakare
     ID 700673263*/
    class BackEndBilling : IBilling
    {
        private const decimal amount = 2800m;
        private int days = 0;

        public BackEndBilling(int _NumberOfDays)
        {
            days = _NumberOfDays;
        }
        public int WorkingDays
        {
            get{return days;}

            set{days = value;}
        }

        public virtual decimal BillingPrice()
        {
            decimal total = amount * days;
            return total;
        }

        public override string ToString()
        {
            return $"Type of Service: {GetType().Name}; Bill per day: {amount}; Total bill for {days} days: ";
            //the toString method is overridden to just display the name of the class and the properties.
        }//end toString()
    }
}
