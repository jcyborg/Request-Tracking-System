﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


namespace RequestTrackerProject.DataClassFolder
{
    /*
     * Created by Jubril Bakare
     * ID 700673263
     */
    class DataAccessObjects
    {
        string url = ConfigurationManager.ConnectionStrings["RequestTrackerProject.Properties.Settings.Setting"].ConnectionString;
        SqlConnection conn;

        public void openConnection()
        {
            if (conn.State==ConnectionState.Closed)
            {
                conn.Open();
            }
        }
        public SqlConnection getConnection()
        {
            if(conn == null)
            {
                conn = new SqlConnection(url);
            }
            
            return conn;
        }

        public void closeConnection()
        {
            conn.Close();
        }

        }
    }

